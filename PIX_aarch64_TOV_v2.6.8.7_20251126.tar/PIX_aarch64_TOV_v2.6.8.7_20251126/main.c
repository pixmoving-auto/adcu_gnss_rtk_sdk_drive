#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "libapi.h"

void printRtcmData(void *data, int length) {
    // to print RTCM
//    printf("RTCM length=%d\n", length);
//    for (int i = 0; i < length; i++) {
//        printf("%02hhx ", *((char *)data + i));
//    }
//    printf("\n=====================RTCM======================\n"); 
}

void printEpheData(void *data, int length) {
    // to print EPHE
    printf("EPHE length=%d\n", length);
    for (int i = 0; i < length; i++) {
        printf("%02hhx ", *((char *)data + i));
    }
    printf("\n=====================EPHE======================\n"); 
}

void printfStatusData(int status) {
    printf("status=%d\n", status);
}

void printLogData(void* buf, int length) {
    printf("%s\n", (char*)buf);
}

int main(int argc, char *argv[]) {
    char               gga[] = "$GPGGA,023352.55,3113.2180600,N,12148.8000000,E,1,00,1.0,-6.078,M,11.078,M,0.0,*60\r\n";
    char               expire_day[128] = {0};
    char               rtcm_freq[128]  = {0};
    RtcmDataResponse   rtcm_data       = {printRtcmData};
    RtcmDataResponse   ephe_data       = {printEpheData};
    RtcmStatusResponse status_data     = {printfStatusData};
    RtcmLogResponse    log_data        = {printLogData};
    
    // startSdk(&rtcm_data, &status_data);
    // setEphCallback(&ephe_data);
    setLogThreshold(1);
    startSdkWithLog(&rtcm_data, &status_data, &log_data);
//    setTlsLogLevel(5);
    // setGridNetMode(GRIDNETID);
    setRtcmUserEpoch("ITRF2008","2016.00");
//    setRtcmUserInfo("csej187822", "v96shf2f");
    setRtcmUserInfo("csej187822", "v96shf2f");
//    setScene("autodriver");
//    setDiagnoShellPath("/home/sdk/luowei/sdkcommon1128/sdkcommon/build/diagno.sh"); 
    while(1){
        // sendEphRequest(SYS_SCOPE_CHINA,CMCC_SYS_GAL|CMCC_SYS_BDS);
        sendGGA(gga, strlen(gga));
        sleep(1);
    }
    return 0;
}
